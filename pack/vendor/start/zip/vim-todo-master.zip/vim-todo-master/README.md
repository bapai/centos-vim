# vim-todo
Better TODO manager plugin for neovim/vim

This plugin is automatically detach from [SpaceVim](https://github.com/SpaceVim/SpaceVim/). you can use it without SpaceVim.

![todo](https://user-images.githubusercontent.com/13142418/61044482-5342e800-a40b-11e9-9d6c-88cc20b06095.png)

## Usage

the only command is `OpenTodo`.

